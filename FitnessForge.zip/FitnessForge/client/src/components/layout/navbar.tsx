import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";

const NavLinks = ({ onClick }: { onClick: (e: React.MouseEvent<HTMLAnchorElement>) => void }) => (
  <>
    <a href="#features" onClick={onClick}>
      <Button variant="ghost" className="text-sm font-medium transition-colors hover:text-primary">
        Features
      </Button>
    </a>
    <a href="#trainers" onClick={onClick}>
      <Button variant="ghost" className="text-sm font-medium transition-colors hover:text-primary">
        Trainers
      </Button>
    </a>
    <a href="#programs" onClick={onClick}>
      <Button variant="ghost" className="text-sm font-medium transition-colors hover:text-primary">
        Programs
      </Button>
    </a>
    <a href="#contact" onClick={onClick}>
      <Button variant="ghost" className="text-sm font-medium transition-colors hover:text-primary">
        Contact
      </Button>
    </a>
  </>
);

export function Navbar() {
  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute('href');
    if (!href) return;

    if (href === '#top') {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      return;
    }

    const element = document.querySelector(href);
    if (!element) return;

    const offset = 80; // Height of the navbar plus some padding
    const elementPosition = element.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - offset;

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-xl items-center justify-between px-4 md:px-8">
        <div className="flex items-center gap-6">
          <a href="#top" onClick={handleScroll} className="flex items-center space-x-2">
            <span className="text-xl font-bold text-primary">FITPRO</span>
          </a>
          <nav className="hidden md:flex items-center space-x-4">
            <NavLinks onClick={handleScroll} />
          </nav>
        </div>

        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="outline" size="icon" className="shrink-0">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[280px] sm:w-[360px]">
            <nav className="flex flex-col space-y-4 mt-6">
              <NavLinks onClick={handleScroll} />
            </nav>
          </SheetContent>
        </Sheet>

        <div className="hidden md:flex items-center space-x-4">
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
            Get Started
          </Button>
        </div>
      </div>
    </header>
  );
}