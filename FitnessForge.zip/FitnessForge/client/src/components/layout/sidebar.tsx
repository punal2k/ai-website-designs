import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Dumbbell, Users, Award, Phone, ChevronRight } from "lucide-react";

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
}

interface SidebarItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const sidebarItems: SidebarItem[] = [
  {
    title: "Features",
    href: "#features",
    icon: Dumbbell,
  },
  {
    title: "Trainers",
    href: "#trainers",
    icon: Users,
  },
  {
    title: "Programs",
    href: "#programs",
    icon: Award,
  },
  {
    title: "Contact",
    href: "#contact",
    icon: Phone,
  },
];

export function Sidebar({ className }: SidebarProps) {
  return (
    <div className={cn("pb-12", className)}>
      <div className="space-y-4 py-4">
        <div className="px-4 py-2">
          <Link href="/">
            <a className="flex items-center">
              <h2 className="text-lg font-semibold tracking-tight">FITPRO</h2>
            </a>
          </Link>
        </div>
        <ScrollArea className="px-1">
          <div className="space-y-1">
            {sidebarItems.map((item, index) => (
              <motion.div
                key={item.href}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link href={item.href}>
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-2 text-base"
                  >
                    <item.icon className="h-5 w-5" />
                    {item.title}
                    <ChevronRight className="ml-auto h-4 w-4" />
                  </Button>
                </Link>
              </motion.div>
            ))}
          </div>
        </ScrollArea>
        <div className="px-4 pt-6">
          <Button className="w-full" size="lg">
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
}
