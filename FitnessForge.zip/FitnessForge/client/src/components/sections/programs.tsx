import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

const programs = [
  {
    title: "Strength Fundamentals",
    duration: "8 weeks",
    level: "Beginner",
    price: "$199",
    image: "https://images.unsplash.com/photo-1487956382158-bb926046304a",
  },
  {
    title: "HIIT Revolution",
    duration: "6 weeks",
    level: "Intermediate",
    price: "$249",
    image: "https://images.unsplash.com/photo-1518459031867-a89b944bffe4",
  },
  {
    title: "Elite Performance",
    duration: "12 weeks",
    level: "Advanced",
    price: "$399",
    image: "https://images.unsplash.com/photo-1518310790390-836058cb000b",
  },
];

export function Programs() {
  return (
    <section id="programs" className="py-24 relative overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-bl from-primary/5 via-background to-background" />

      <div className="container relative z-10">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl font-bold text-center mb-12"
        >
          Training Programs
        </motion.h2>

        <div className="grid gap-8 md:grid-cols-3">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="group overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
                <div className="relative h-48 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-10" />
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                  />
                </div>

                <CardHeader className="relative">
                  <div className="flex justify-between items-center mb-2">
                    <Badge variant="secondary" className="group-hover:bg-primary/20 transition-colors duration-300">
                      {program.level}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {program.duration}
                    </span>
                  </div>
                  <CardTitle className="group-hover:text-primary transition-colors duration-300">
                    {program.title}
                  </CardTitle>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Comprehensive program designed to help you achieve your fitness goals.
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold text-primary">
                      {program.price}
                    </span>
                    <Button variant="ghost" className="group-hover:text-primary transition-colors duration-300">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}