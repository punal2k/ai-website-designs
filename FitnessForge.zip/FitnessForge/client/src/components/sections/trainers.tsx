import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

const trainers = [
  {
    name: "Sarah Johnson",
    specialty: "Strength Training",
    image: "https://images.unsplash.com/photo-1529165980561-f19d4acc4f3f",
    experience: "10+ years",
  },
  {
    name: "Mike Chen",
    specialty: "HIIT Expert",
    image: "https://images.unsplash.com/photo-1544972917-3529b113a469",
    experience: "8+ years",
  },
  {
    name: "Emma Wilson",
    specialty: "Yoga Instructor",
    image: "https://images.unsplash.com/photo-1540206063137-4a88ca974d1a",
    experience: "12+ years",
  },
];

export function Trainers() {
  return (
    <section id="trainers" className="py-24 relative overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-tr from-primary/5 via-background to-background" />

      <div className="container relative z-10">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl font-bold text-center mb-12"
        >
          Meet Our Expert Trainers
        </motion.h2>

        <div className="grid gap-8 md:grid-cols-3">
          {trainers.map((trainer, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="group overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
                <CardContent className="p-6">
                  <div className="relative mb-6">
                    <Avatar className="h-32 w-32 mx-auto ring-4 ring-primary/10 group-hover:ring-primary/20 transition-all duration-300">
                      <AvatarImage src={trainer.image} alt={trainer.name} />
                    </Avatar>
                    <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>

                  <h3 className="text-xl font-semibold text-center mb-2 group-hover:text-primary transition-colors duration-300">
                    {trainer.name}
                  </h3>

                  <div className="flex flex-col items-center gap-2">
                    <Badge variant="secondary" className="group-hover:bg-primary/20 transition-colors duration-300">
                      {trainer.specialty}
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      {trainer.experience} Experience
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}