import { HeroGeometric } from "@/components/ui/shape-landing-hero";

export function Hero() {
  return (
    <HeroGeometric 
      badge="Elite Fitness"
      title1="Transform Your Body"
      title2="Transform Your Life"
    />
  );
}