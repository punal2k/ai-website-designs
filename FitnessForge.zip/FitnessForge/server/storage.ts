import { newsletter, type Newsletter, type InsertNewsletter } from "@shared/schema";

export interface IStorage {
  addNewsletterSubscriber(sub: InsertNewsletter): Promise<Newsletter>;
  getNewsletterSubscriberByEmail(email: string): Promise<Newsletter | undefined>;
}

export class MemStorage implements IStorage {
  private subscribers: Map<number, Newsletter>;
  currentId: number;

  constructor() {
    this.subscribers = new Map();
    this.currentId = 1;
  }

  async addNewsletterSubscriber(sub: InsertNewsletter): Promise<Newsletter> {
    const id = this.currentId++;
    const subscriber: Newsletter = { ...sub, id };
    this.subscribers.set(id, subscriber);
    return subscriber;
  }

  async getNewsletterSubscriberByEmail(email: string): Promise<Newsletter | undefined> {
    return Array.from(this.subscribers.values()).find(
      (sub) => sub.email === email
    );
  }
}

export const storage = new MemStorage();
