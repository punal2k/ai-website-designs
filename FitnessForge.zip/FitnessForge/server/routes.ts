import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertNewsletterSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express) {
  app.post("/api/newsletter", async (req, res) => {
    try {
      const data = insertNewsletterSchema.parse(req.body);
      const existing = await storage.getNewsletterSubscriberByEmail(data.email);
      
      if (existing) {
        return res.status(400).json({ message: "Email already subscribed" });
      }

      const subscriber = await storage.addNewsletterSubscriber(data);
      res.status(201).json(subscriber);
    } catch (err) {
      if (err instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data" });
      }
      throw err;
    }
  });

  return createServer(app);
}
